<p dir="ltr">BASES SORTEO AIRSH HAIR - REVLON UNIQ ONE</p>

<p>&nbsp;</p>

<p dir="ltr">1. &Aacute;MBITO</p>

<p>&nbsp;</p>

<p dir="ltr">Pen&iacute;nsula, Canarias y Baleares. Dirigida a todos los internautas que accedan a cualquier medio digital, con los requisitos y las limitaciones especificadas m&aacute;s adelante</p>

<p>&nbsp;</p>

<p dir="ltr">2. VIGENCIA DEL SORTEO</p>

<p>&nbsp;</p>

<p dir="ltr">Desde las 12:00h del d&iacute;a 21/04/17 hasta las 23:59h del d&iacute;a 25/04/17.</p>

<p>&nbsp;</p>

<p dir="ltr">3. MEC&Aacute;NICA</p>

<p>&nbsp;</p>

<p dir="ltr">3.1 Podr&aacute;n participar los internautas que accedan por cualquier medio digital a la landing creada para tal sorteo: www.airshhair.com/landing/ e incluir su direcci&oacute;n de correo electr&oacute;nico (tras registrarse, cumplimentando los datos personales que se le solicitan). A continuaci&oacute;n, recibir&aacute;n un correo en el que se le comunicar&aacute; cu&aacute;l de los dos premios ofrecidos, han ganado al azar, junto con un c&oacute;digo para canjear por el premio obtenido:</p>

<p>&nbsp;</p>

<p dir="ltr">Un pack formado por 3 productos Revlon Uniq One o un c&oacute;digo descuento de un 15% para canjear en la tienda de Amazon de Airsh Air, accesible desde http://amzn.to/2pBgPmL</p>

<p>&nbsp;</p>

<p dir="ltr">Los participantes solamente podr&aacute;n participar una vez.</p>

<p>&nbsp;</p>

<p dir="ltr">3.2. Protecci&oacute;n de Datos</p>

<p>&nbsp;</p>

<p dir="ltr">De acuerdo con lo dispuesto en la Ley 34/2002, de 11 de julio, de servicios de la sociedad de la informaci&oacute;n y de comercio electr&oacute;nico, as&iacute; como en la normativa de protecci&oacute;n de datos: Ley 15/1999, de 13 de diciembre de Protecci&oacute;n de Datos de Car&aacute;cter Personal y su reglamento de desarrollo; cada participante queda expresamente informado de la incorporaci&oacute;n de sus datos personales a un fichero automatizado propiedad de Airsh Air con la finalidad de gestionar su participaci&oacute;n en el SORTEO.</p>

<p>&nbsp;</p>

<p dir="ltr">La aceptaci&oacute;n de los participantes y de los ganadores para que puedan ser tratados sus datos en la forma establecida en este apartado tiene siempre car&aacute;cter revocable, sin efectos retroactivos, conforme a lo que disponen la LOPD 15/199 de 13 de diciembre y su reglamento de desarrollo. No obstante lo anterior, el revocar la aceptaci&oacute;n durante el desarrollo del SORTEO, conllevar&aacute; la imposibilidad de participar en el mismo o de hacerle entrega de los premios.</p>

<p>&nbsp;</p>

<p dir="ltr">Para poder participar en el SORTEO, es obligatorio ser mayor de 18 a&ntilde;os y cumplimentar, de forma veraz y exacta, todos los datos solicitados aceptando las presentes las Bases Legales; la inexactitud, falsedad o negativa a facilitar tales datos, impedir&aacute; su participaci&oacute;n en el SORTEO.</p>

<p>&nbsp;</p>

<p dir="ltr">La identidad de los ganadores en el momento de la entrega de los premios, se acreditar&aacute; por medio de una direcci&oacute;n de email que tendr&aacute; que ser verificada.</p>

<p>&nbsp;</p>

<p dir="ltr">Se informa a los participantes que podr&aacute;n ejercitar los derechos de acceso, rectificaci&oacute;n, cancelaci&oacute;n y oposici&oacute;n dirigi&eacute;ndose al responsable del tratamiento, Rodri Fuerte Cosmetics S.L. (Atenci&oacute;n al cliente), Guzm&aacute;n el Bueno,9 &nbsp;Bajo Derecha, 28.015, Madrid o al correo atencionalcliente@airshair.com. Cualquier comunicaci&oacute;n en este sentido deber&aacute; ir acompa&ntilde;ada de fotocopia del DNI del solicitante. Igualmente, cada participante comunicar&aacute; a Rodri Fuerte Cosmetics S.L.. cualquier modificaci&oacute;n de los datos personales aportados al participar en el presente SORTEO dirigi&eacute;ndose al responsable del tratamiento en las direcciones anteriormente indicadas.</p>

<p>&nbsp;</p>

<p dir="ltr">Por tanto, y en base a todo lo anterior, a los efectos y fines indicados y en su calidad de participantes y/o ganadores, al participar en el presente SORTEO otorgan su consentimiento expreso para la inclusi&oacute;n y tratamiento de los datos solicitados en el fichero de referencia.</p>

<p>&nbsp;</p>

<p dir="ltr">La participaci&oacute;n en el presente SORTEO supone el conocimiento y aceptaci&oacute;n expresa de las presentes Bases.</p>

<p>&nbsp;</p>

<p dir="ltr">4. PREMIOS</p>

<p>&nbsp;</p>

<p dir="ltr">- Habr&aacute; 60 packs de 3 productos Revlon Uniq One Gratis.</p>

<p>&nbsp;</p>

<p dir="ltr">Se entregar&aacute; un pack por cada hora entre las 12:00 y las 00:00 durante cada d&iacute;a en los que la promoci&oacute;n est&aacute; activa.. La mec&aacute;nica consiste en que las horas asociadas a cada premio se entrega un pack con esa cadencia horaria, de tal modo que si pasado el tiempo de cada franja horaria no se ha entregado alg&uacute;n pack, se van acumulando de tal modo que el primer usuario que acceda a participar lo reciba de manera inmediata. En el caso de que que no ser premiado con uno de los packs, el premio obtenido ser&aacute; un c&oacute;digo descuento del 15% a canjear en la tienda de Amazon de Airsh Air.</p>

<p><br />
&nbsp;</p>

<p dir="ltr">Condiciones de los premios:</p>

<p>&nbsp;</p>

<p dir="ltr">- El c&oacute;digo descuento del 15% ser&aacute; canjeable en cualquiera de los productos de la tienda de Amazon de Airsh Air (http://amzn.to/2pBgPmL), pudiendo aplicarse a un solo producto o a un conjunto de ellos, sin importe m&iacute;nimo de compra, seg&uacute;n las condiciones detalladas en las presentes bases.</p>

<p>&nbsp;</p>

<ul style="list-style-type:disc">
	<li dir="ltr">
	<p dir="ltr">En caso de ser premiado con uno de los packs, Airsh Air se reserva el derecho de ponerse en contacto por el correo electr&oacute;nico facilitado por el ganador en el momento de participar, para pedirle los datos postales para hacerle llegar el premio por correo postal.</p>
	</li>
</ul>

<p>&nbsp;</p>

<p dir="ltr">Solo podr&aacute; canjearse 1 c&oacute;digo por cada pedido en la tienda de Amazon de Airsh Air. Canje de c&oacute;digo v&aacute;lido hasta el 30 de abril de 2017.</p>

<p>&nbsp;</p>

<p dir="ltr">Para canjear los c&oacute;digos, ser&aacute; condici&oacute;n indispensable seguir las siguientes instrucciones:</p>

<p>&nbsp;</p>

<p dir="ltr">Para el premio de c&oacute;digo de descuento del 15%:</p>

<p>&nbsp;</p>

<p dir="ltr">1) Iniciar sesi&oacute;n o registrarse en www.amazon.es. 2) Acceder a la tienda de Airsh Air dentro de Amazon, accesible desde <a href="http://amzn.to/2pBgPmL">http://amzn.to/2pBgPmL</a>. 3) Elegir los productos a comprar y &ldquo;A&ntilde;adir a la cesta&rdquo; 4) En el proceso de pago, introducir el c&oacute;digo descuento del 15% que se indica en la promoci&oacute;n.</p>

<p>&nbsp;</p>

<p dir="ltr">Para canjear el premio de 1 pack de productos Revlon Uniq One</p>

<p>&nbsp;</p>

<p dir="ltr">1) Airsh Hair se pondr&aacute; en contacto con el premiado a trav&eacute;s del correo electr&oacute;nico facilitado, para solicitar los datos de env&iacute;o del pack premiado.</p>

<p>&nbsp;</p>

<p dir="ltr">5. LIMITACIONES</p>

<p>&nbsp;</p>

<p dir="ltr">No podr&aacute;n participar en esta acci&oacute;n promocional, los menores de 18 a&ntilde;os.</p>

<p dir="ltr">Igualmente no podr&aacute;n participar los internautas que accedan con una IP no espa&ntilde;ola.</p>

<p>&nbsp;</p>

<p dir="ltr">Los premios son personales e intransferibles, no pudiendo ser canjeados por ning&uacute;n otro servicio ni cedido por los ganadores a terceras personas. Igualmente no podr&aacute;n ser canjeados por dinero.</p>

<p>&nbsp;</p>

<p dir="ltr">6. ADJUDICATARIOS DE LOS PREMIOS</p>

<p>&nbsp;</p>

<p dir="ltr">La participaci&oacute;n en esta acci&oacute;n promocional supondr&aacute;:</p>

<p>&nbsp;</p>

<p dir="ltr">- La plena aceptaci&oacute;n de las presentes bases (ante posibles dudas en la interpretaci&oacute;n de las mismas prevalecer&aacute; el criterio del organizador).</p>

<p dir="ltr">- La renuncia expresa al fuero que pudiera corresponder a los participantes, aceptando &eacute;stos los Tribunales y Juzgados de Madrid capital como competentes para dilucidar cualquier reclamaci&oacute;n.</p>

<p>&nbsp;</p>

<p dir="ltr">Los premios estar&aacute;n sujetos a la Legislaci&oacute;n vigente en cada momento en materia de I.R.P.F.</p>

<p>&nbsp;</p>

<p dir="ltr">7. DIFUSI&Oacute;N DEL SORTEO</p>

<p>&nbsp;</p>

<p dir="ltr">Esta acci&oacute;n ser&aacute; difundida en determinados medios digitales.</p>

<p>&nbsp;</p>

<p dir="ltr">Las Bases estar&aacute;n a disposici&oacute;n de los participantes en este link</p>

<p dir="ltr">Rodri Fuerte Cosmetics S.L. se reserva la posibilidad de modificar o cancelar la presente acci&oacute;n promocional y las presentes Bases total o parcialmente.</p>

<p>&nbsp;</p>

<p dir="ltr">8. RENUNCIA O IMPOSIBILIDAD PARA DISFRUTAR DEL PREMIO</p>

<p>&nbsp;</p>

<p dir="ltr">En el caso de que por cualquier circunstancia, los ganadores no aceptaran los premios perder&aacute;n su condici&oacute;n de ganadores.</p>

<p>&nbsp;</p>

<p dir="ltr">9. DERECHO DE ELIMINACI&Oacute;N DE PARTICIPACIONES FRAUDULENTAS</p>

<p>&nbsp;</p>

<p dir="ltr">Rodri Fuerte Cosmetics S.L se reserva el derecho de eliminar en cualquier momento a cualquier participante que defraude o altere el buen funcionamiento y el transcurso normal y reglamentario de la presente acci&oacute;n promocional o no cumpla las presentes Bases. Rodri Fuerte Cosmetics S.Lpretende que todos los participantes, participen en igualdad de condiciones en la presente acci&oacute;n promocional y con estricto respeto a las normas de buena fe.</p>

<p>&nbsp;</p>

<p dir="ltr">De la misma manera, Rodri Fuerte Cosmetics S.L se reserva el derecho a eliminar a cualquier participante que utilice palabras, t&eacute;rminos y/o participaciones que est&eacute;n relacionadas con la violencia, pornograf&iacute;a, racismo, xenofobia, apolog&iacute;a al terrorismo y en general, que sean contrarias a la ley o al orden p&uacute;blico.</p>

<p>&nbsp;</p>

<p dir="ltr">10. EXCLUSI&Oacute;N DE RESPONSABILIDADES</p>

<p>&nbsp;</p>

<p dir="ltr">Rodri Fuerte Cosmetics S.L no incurrir&aacute; en ning&uacute;n tipo de responsabilidad si el premio no es recibido seg&uacute;n sus instrucciones o si no es disfrutado por el ganador.</p>
<p>Revlon ni ninguna otra marca patrocina ni forma parte de esta campaña realizada por Airsh Air</p>

<p>&nbsp;</p>

<p dir="ltr">Rodri Fuerte Cosmetics S.L no se hace responsable del mal funcionamiento de la plataforma alojada en <a href="http://www.airshhair.com/landing">http://www.airshhair.com/landing</a>.</p>

<p>&nbsp;</p>

<p dir="ltr">11. ENV&Iacute;O DE PROMOCIONES Y OTROS SORTEOS</p>

<p>&nbsp;</p>

<p dir="ltr">Rodri Fuerte Cosmetics S.L se reserva el derecho al env&iacute;o de correos electr&oacute;nicos promocionales relacionados con la marca Airsh Hair, a todo usuario que haya participado con su email en la presente promoci&oacute;n. Posteriormente, podr&aacute; dar de baja sus datos de la promoci&oacute;n enviando un email a <a href="mailto:atencionalcliente@airshhair.com">atencionalcliente@airshhair.com</a> indicando el deseo de darse de baja en nuestra newsletter.</p>

<div>&nbsp;</div>
