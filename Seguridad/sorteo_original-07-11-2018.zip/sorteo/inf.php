<?php
    $version = phpversion();
print $version;
?>